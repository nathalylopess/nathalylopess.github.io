var carrinho = document.getElementById('carrinho_pag');
carrinho.innerHTML = '<a href="file:///C:/Users/river/OneDrive/%C3%81rea%20de%20Trabalho/Infoweb/Design%20Web/projeto%20design/carrinho/carrinho.html"><i class="bx bx-cart-alt bx-md bx-tada"></i></a>'

var login = document.getElementById('login_pag');
login.innerHTML = '<a href="file:///C:/Users/river/OneDrive/%C3%81rea%20de%20Trabalho/Infoweb/Design%20Web/projeto%20design/login/pagina_de_login.html"><i class="bx bx-user bx-md "></i></a>'
